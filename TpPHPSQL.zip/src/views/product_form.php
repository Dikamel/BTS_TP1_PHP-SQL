<?php

namespace App\views; ?>


<h1><?= isset($produit) ? 'Modifier' : 'Ajouter' ?> un produit</h1>

<form method="post" action="index.php?action=save">
    <input type="hidden" name="id" value="<?= $produit['id_product'] ?? null ?>">
    
    <label>Nom :</label>
    <input type="text" name="nom" value="<?= $produit['name'] ?? '' ?>"
        required><br>

    <label>Description :</label>
    <textarea name="description"><?= $produit['description'] ?? ''
                                    ?></textarea><br>

    <label>Prix :</label>
    <input type="number" step="0.01" name="prix" value="<?= $produit['price']
                                                            ?? '' ?>" required><br>

    <label for="fournisseur">Fournisseur</label>
    <select id="fournisseur" name="fournisseur" required>
        <?php foreach ($suppliers as $s) : ?>
            <option value="<?= $s['id_supplier'] ?>" <?= ($s['name'] == ($produit['supplier'] ?? 0)) ? 'selected' : '' ?>><?= $s['name'] ?></option>          
        <?php endforeach; ?>
    </select><br>
    <button type="submit">Enregistrer</button>
</form>