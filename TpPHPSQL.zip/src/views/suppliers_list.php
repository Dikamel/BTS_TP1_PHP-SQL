<php namespace App\views ; ?>



<h1>Liste des fournisseurs</h1>
<a href="index.php?action=supplier_form">Ajouter un fournisseur</a> <br>
<a href="index.php?action=products_list">Voir la liste des produits</a>
<table border="1">
    <tr>
        <th>Nom</th>
        <th>Email</th>
        <th>Téléphone</th>
        <th>Nb de produits</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($suppliers as $s): ?>
        <tr>
            <td><?= htmlspecialchars($s['name']) ?></td>
            <td><?= htmlspecialchars(string: $s['email']) ?></td>
            <td><?= htmlspecialchars($s['phone']) ?></td>
            <td><?= htmlspecialchars(string: ($s['nb_products']) ?? 'N/A') ?></td>
            <td>
                <a href="index.php?action=supplier_form&id=<?= $s['id_supplier'] ?>">Modifier</a>
                <a href="index.php?action=delete_supplier&id=<?= $s['id_supplier'] ?>">Supprimer</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>