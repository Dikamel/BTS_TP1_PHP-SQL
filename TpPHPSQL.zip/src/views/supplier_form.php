<?php

namespace App\views; ?>


<h1><?= isset($supplier) ? 'Modifier' : 'Ajouter' ?> un fournisseur</h1>

<form method="post" action="index.php?action=save_form_supplier">
    <input type="hidden" name="id" value="<?= $supplier['id_supplier'] ?? null ?>">
    
    <label>Nom :</label>
    <input type="text" name="nom" value="<?= $supplier['name'] ?? '' ?>"
        required><br>

    <label>Email :</label>
    <input type="text" name="email" value="<?= $supplier['email'] ?? '' ?>"><br>

    <label>Téléphone :</label>
    <input type="text" name="telephone" value="<?= $supplier['phone']   ?? '' ?>"><br>

    <button type="submit">Enregistrer</button>
</form>