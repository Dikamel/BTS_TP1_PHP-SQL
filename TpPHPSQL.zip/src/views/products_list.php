<?php namespace App\views ;?>


<h1>Liste des produits</h1>
<a href="index.php?action=form">Ajouter un produit</a> <br>
<a href="index.php?action=suppliers_list">Voir la liste des fournisseurs</a>
<table border="1">
    <tr>
        <th>Nom</th>
        <th>Descritpion</th>
        <th>Prix</th>
        <th>Fournisseurs</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($produits as $p): ?>
        <tr>
            <td><?= htmlspecialchars($p['name']) ?></td>
            <td><?= htmlspecialchars(string: $p['description']) ?></td>
            <td><?= $p['price'] ?> €</td>
            <td><?= htmlspecialchars(string: $p['supplier']) ?></td>
            <td>
                <a href="index.php?action=form&id=<?= $p['id_product'] ?>">Modifier</a>
                <a href="index.php?action=delete_product&id=<?= $p['id_product'] ?>">Supprimer</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>